export const API = 'https://api.unsplash.com'
export const ACCESS_KEY = '099bd47168f041cedf30bb962aef5f2d2bd4785cbe0615c7d217ccc03e7a17f9';

export const GET_PHOTOS_RANDOM = API + '/photos/random';
export const SEARCH_PHOTOS = API + '/search/photos';
export const MAX_RESULTS = 5
